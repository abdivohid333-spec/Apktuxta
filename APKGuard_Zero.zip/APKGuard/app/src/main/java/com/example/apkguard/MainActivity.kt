package com.example.apkguard

import android.app.Activity
import android.content.Intent
import android.content.pm.PackageInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.ViewGroup
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileOutputStream

class MainActivity : Activity() {
    private lateinit var content: LinearLayout
    private lateinit var report: TextView
    private var apkFile: File? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val scroll = ScrollView(this)
        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28, 36, 28, 32)
            setBackgroundColor(0xFF101820.toInt())
        }
        scroll.addView(content)
        setContentView(scroll)

        content.addView(TextView(this).apply {
            text = "🛡 APK GUARD"
            textSize = 28f
            gravity = Gravity.CENTER
            setTextColor(0xFFFFFFFF.toInt())
        }, matchWrap())

        content.addView(TextView(this).apply {
            text = "APK o‘rnatishdan oldin xavfsizlik tekshiruvi"
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(0xFFB8C5D1.toInt())
            setPadding(0, 10, 0, 24)
        }, matchWrap())

        addButton("ILOVANI FAOLLASHTIRISH") {
            Toast.makeText(this, "APK Guard faollashtirildi", Toast.LENGTH_SHORT).show()
            addButton("APK TANLASH VA TEKSHIRISH") { chooseApk() }
        }

        report = TextView(this).apply {
            text = "Hozircha APK tanlanmagan."
            textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
            setPadding(0, 22, 0, 16)
        }
        content.addView(report, matchWrap())
    }

    private fun matchWrap() = LinearLayout.LayoutParams(
        ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
    )

    private fun addButton(label: String, action: () -> Unit) {
        val b = Button(this).apply {
            text = label
            isAllCaps = false
            setOnClickListener { action() }
        }
        content.addView(b, LinearLayout.LayoutParams(
            ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT
        ).apply { bottomMargin = 12 })
    }

    private fun chooseApk() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/vnd.android.package-archive"
        }
        startActivityForResult(intent, 100)
    }

    @Deprecated("Uses the compatible document-picker result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 100 && resultCode == RESULT_OK) {
            data?.data?.let { inspect(it) }
        }
    }

    private fun inspect(uri: Uri) {
        try {
            val displayName = queryName(uri)
            val file = File(cacheDir, "apkguard_scan.apk")
            contentResolver.openInputStream(uri).use { input ->
                requireNotNull(input) { "APK faylni o‘qib bo‘lmadi" }
                FileOutputStream(file).use { output -> input.copyTo(output) }
            }
            apkFile = file

            val flags = PackageManager.GET_PERMISSIONS or PackageManager.GET_ACTIVITIES or
                PackageManager.GET_SERVICES or PackageManager.GET_RECEIVERS or PackageManager.GET_PROVIDERS
            val info = getArchiveInfo(file.absolutePath, flags)
                ?: throw IllegalArgumentException("Fayl Android APK sifatida o‘qilmadi.")

            val permissions = info.requestedPermissions?.toList() ?: emptyList()
            val sensitive = permissions.filter { p ->
                listOf("CAMERA", "RECORD_AUDIO", "READ_CONTACTS", "READ_SMS",
                    "RECEIVE_SMS", "ACCESS_FINE_LOCATION", "READ_CALL_LOG",
                    "WRITE_CALL_LOG", "READ_PHONE_STATE", "REQUEST_INSTALL_PACKAGES",
                    "SYSTEM_ALERT_WINDOW").any { p.endsWith(it) }
            }
            val internet = permissions.any { it == "android.permission.INTERNET" }
            val level = when {
                sensitive.size >= 4 -> "SHUBHALI: bir nechta sezgir ruxsat so‘raydi"
                sensitive.isNotEmpty() -> "DIQQAT: sezgir ruxsatlar mavjud"
                else -> "Dastlabki tekshiruvda sezgir ruxsat topilmadi"
            }
            val permissionText = if (permissions.isEmpty()) "Ko‘rsatilmagan" else
                permissions.joinToString("\n") { "• ${it.substringAfterLast('.')}" }

            report.text = """
FAYL: $displayName
PAKET: ${info.packageName}
VERSIYA: ${info.versionName ?: "Noma'lum"}

DASTLABKI BAHO:
$level

ILOVA TUZILMASI:
Faoliyatlar: ${info.activities?.size ?: 0}
Xizmatlar: ${info.services?.size ?: 0}
Qabul qiluvchilar: ${info.receivers?.size ?: 0}
Kontent provayderlar: ${info.providers?.size ?: 0}
Internet ruxsati: ${if (internet) "BOR" else "YO‘Q"}

SEZGIR RUXSATLAR:
${if (sensitive.isEmpty()) "Aniqlanmadi" else sensitive.joinToString("\n") { "• ${it.substringAfterLast('.')}" }}

BARCHA RUXSATLAR:
$permissionText

MUHIM:
Bu statik dastlabki tahlil. U APK ishga tushganda yashirin serverga
ulanmasligini yoki mutlaqo xavfsizligini kafolatlamaydi.
            """.trimIndent()

            addButton("O‘RNATISH") { openInstaller() }
            addButton("O‘RNATMASLIK") {
                apkFile = null
                report.text = "O‘rnatish bekor qilindi."
            }
        } catch (e: Exception) {
            apkFile = null
            report.text = "Tekshiruv amalga oshmadi:\n${e.message}\nBu fayl xavfsiz deb baholanmaydi."
        }
    }

    private fun queryName(uri: Uri): String {
        var name = "tanlangan.apk"
        contentResolver.query(uri, null, null, null, null)?.use { c ->
            val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && i >= 0) name = c.getString(i)
        }
        return name
    }

    @Suppress("DEPRECATION")
    private fun getArchiveInfo(path: String, flags: Int): PackageInfo? =
        if (Build.VERSION.SDK_INT >= 33) {
            packageManager.getPackageArchiveInfo(path, PackageManager.PackageInfoFlags.of(flags.toLong()))
        } else {
            packageManager.getPackageArchiveInfo(path, flags)
        }

    private fun openInstaller() {
        val file = apkFile
        if (file == null || !file.exists()) {
            Toast.makeText(this, "Avval APK tanlang", Toast.LENGTH_SHORT).show()
            return
        }
        val uri = FileProvider.getUriForFile(this, "$packageName.fileprovider", file)
        val intent = Intent(Intent.ACTION_VIEW).apply {
            setDataAndType(uri, "application/vnd.android.package-archive")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try {
            startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(this, "Android o‘rnatish oynasini ochib bo‘lmadi: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
